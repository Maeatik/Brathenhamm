import pygame
import random
import pyautogui

pygame.init()

window = pygame.display.set_mode((600, 600))

pygame.display.set_caption("Треугольник Серпинского")

Triangle = [[300, 50], [100, 550], [500, 550]]

x, y = random.randint(0, 600), random.randint(0, 600)

RUN = True
count = 0

PAUSED = False
while RUN:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            RUN = False

    if PAUSED == False:
        A = random.randint(0, 2)
        x, y = .5 * (x + Triangle[A][0]), .5*(y + Triangle[A][1]) # Вычисление новой точки

        color = window.get_at((int(x), int(y)))

        if color == (255, 255, 255, 255):
            count = count + 1
        else:
            count = 0
        if count == 100:
            print("That's all")
            PAUSED = True
        pygame.draw.line(window, (255, 255, 255), (x, y), (x, y), 1)
        pygame.display.update()

pygame.quit()

