import javafx.beans.InvalidationListener;
import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.scene.shape.Line;
import javafx.scene.shape.Polygon;
import javafx.scene.shape.Polyline;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

public class AthensController {

    @FXML
    private AnchorPane pane;

    @FXML
    private Button decreaseButton;

    @FXML
    private Button increaseButton;

    @FXML
    private TextField setXField;

    @FXML
    private TextField setYField;

    @FXML
    private Button toLeftButton;

    @FXML
    private Button toRightButton;

    @FXML
    private Button SectionButton;

    @FXML
    private Button triangleButton;

    @FXML
    private Line line;

    @FXML
    private Polyline triangle;

    @FXML
    void DecreaseHandler(ActionEvent event)
    {
        if (line.isVisible() == true)
        {
            double xStart = line.getStartX(),
                    xEnd = line.getEndX(),
                    yStart = line.getStartY(),
                    yEnd = line.getEndY();

            xSection[0] = xStart;
            xSection[1] = xEnd;

            ySection[0] = yStart;
            ySection[1] = yEnd;


            double xscale[] = new double[2];
            double yscale[] = new double[2];

            double kX = 0.9;
            double xY = 0.9;

            double[][] scalingMatrix = {
                    {kX, 0, 0},
                    {0, xY, 0},
                    {0, 0, 1}};

            double newCoords[][] = {{0, 0, 0}};

            for (int m = 0; m < 2; m++)
            {
                double xChosenPoint = xSection[m];
                double yChosenPoint = ySection[m];
                double[][] chosenPointMatrix = {{xChosenPoint, yChosenPoint, 1}};
                for (int i = 0; i < 1; i++)
                {
                    for (int j = 0; j < 3; j++)
                    {
                        double newValue = 0;
                        for (int k = 0; k < 3; k++)
                        {
                            newValue = newValue + chosenPointMatrix[i][k] * scalingMatrix[k][j];
                        }
                        newCoords[i][j] = newValue;
                    }
                }
                xscale[m] = newCoords[0][0];
                yscale[m] = newCoords[0][1];

            }
            for (int i = 0; i <2; i++)
            {
                if (i == 1)
                {
                    line.setStartX(xscale[i]);
                    line.setStartY(yscale[i]);
                    line.setEndX(xscale[i - (xscale.length - 1)]);
                    line.setEndY(yscale[i - (xscale.length - 1)]);
                }
                else
                {
                    line.setStartX(xscale[i]);
                    line.setStartY(yscale[i]);
                    line.setEndX(xscale[i + 1]);
                    line.setEndY(yscale[i + 1]);
                }
            pane.getChildren().addAll();
            }
        }

        if (triangle.isVisible() == true)
        {
            ObservableList<Double> trianglePoints = triangle.getPoints();

            double firstPointX = trianglePoints.get(0),
                   firstPointY = trianglePoints.get(1),
                   secondPointX =  trianglePoints.get(2),
                   secondPointY = trianglePoints.get(3),
                   thirdPointX = trianglePoints.get(4),
                   thirdPointY = trianglePoints.get(5);


            xTriangle[0] = firstPointX; xTriangle[1] = secondPointX; xTriangle[2] = thirdPointX;
            yTriangle[0] = firstPointY; yTriangle[1] = secondPointY; yTriangle[2] = thirdPointY;


            double xscale[] = new double[3];
            double yscale[] = new double[3];


            double kX = 0.9;
            double xY = 0.9;

            double[][] scalingMatrix = {
                    {kX, 0, 0},
                    {0, xY, 0},
                    {0, 0, 1}};

            double newCoords[][] = {{0, 0, 0}};

            for (int m = 0; m < 3; m++)
            {
                double xChosenPoint = xTriangle[m];
                double yChosenPoint = yTriangle[m];
                double[][] chosenPointMatrix = {{xChosenPoint, yChosenPoint, 1}};
                for (int i = 0; i < 1; i++)
                {
                    for (int j = 0; j < 3; j++)
                    {
                        double newValue = 0;
                        for (int k = 0; k < 3; k++)
                        {
                            newValue = newValue + chosenPointMatrix[i][k] * scalingMatrix[k][j];
                        }
                        newCoords[i][j] = newValue;
                    }
                }
                xscale[m] = newCoords[0][0];
                yscale[m] = newCoords[0][1];

            }
            ObservableList<Double> newVal = FXCollections.observableArrayList();

            newVal.add(0,xscale[0]);
            newVal.add(1,yscale[0]);
            newVal.add(2,xscale[1]);
            newVal.add(3,yscale[1]);
            newVal.add(4,xscale[2]);
            newVal.add(5,yscale[2]);

            triangle.getPoints().setAll(newVal);
        }
    }

    @FXML
    void IncreaseHandler(ActionEvent event)
    {
        if (line.isVisible() == true)
        {
            double xStart = line.getStartX(),
                    xEnd = line.getEndX(),
                    yStart = line.getStartY(),
                    yEnd = line.getEndY();

            xSection[0] = xStart;
            xSection[1] = xEnd;

            ySection[0] = yStart;
            ySection[1] = yEnd;


            double xscale[] = new double[2];
            double yscale[] = new double[2];

            double kX = 1.1;
            double xY = 1.1;

            double[][] scalingMatrix = {
                    {kX, 0, 0},
                    {0, xY, 0},
                    {0, 0, 1}};

            double newCoords[][] = {{0, 0, 0}};

            for (int m = 0; m < 2; m++)
            {
                double xChosenPoint = xSection[m];
                double yChosenPoint = ySection[m];
                double[][] chosenPointMatrix = {{xChosenPoint, yChosenPoint, 1}};
                for (int i = 0; i < 1; i++)
                {
                    for (int j = 0; j < 3; j++)
                    {
                        double newValue = 0;
                        for (int k = 0; k < 3; k++)
                        {
                            newValue = newValue + chosenPointMatrix[i][k] * scalingMatrix[k][j];
                        }
                        newCoords[i][j] = newValue;
                    }
                }
                xscale[m] = newCoords[0][0];

                yscale[m] = newCoords[0][1];



            }
//            double xx = newCoords[0][0]-xscale[0];
//            double yy = newCoords[0][1]-yscale[0];
//            double layX =  line.getLayoutX();
//            double layY = line.getLayoutY();
//            line.setLayoutX(layX - xx);
//            line.setLayoutY(layY - yy);
//            line.setLayoutX(layX - xx);
//            line.setLayoutY(layY - yy);
            for (int i = 0; i <2; i++)
            {
                if (i == 1)
                {
                    line.setStartX(xscale[i]);
                    line.setStartY(yscale[i]);
                    line.setEndX(xscale[i - 1]);
                    line.setEndY(yscale[i - 1]);
                }
                else
                {
                    line.setStartX(xscale[i]);
                    line.setStartY(yscale[i]);
                    line.setEndX(xscale[i + 1]);
                    line.setEndY(yscale[i + 1]);
                }
            }

        }

        if (triangle.isVisible() == true)
        {
            ObservableList<Double> trianglePoints = triangle.getPoints();

            double firstPointX = trianglePoints.get(0),
                    firstPointY = trianglePoints.get(1),
                    secondPointX = trianglePoints.get(2),
                    secondPointY = trianglePoints.get(3),
                    thirdPointX = trianglePoints.get(4),
                    thirdPointY = trianglePoints.get(5);


            xTriangle[0] = firstPointX;
            xTriangle[1] = secondPointX;
            xTriangle[2] = thirdPointX;
            yTriangle[0] = firstPointY;
            yTriangle[1] = secondPointY;
            yTriangle[2] = thirdPointY;


            double xscale[] = new double[3];
            double yscale[] = new double[3];


            double kX = 1.1;
            double xY = 1.1;

            double[][] scalingMatrix = {
                    {kX, 0, 0},
                    {0, xY, 0},
                    {0, 0, 1}};

            double newCoords[][] = {{0, 0, 0}};

            for (int m = 0; m < 3; m++) {
                double xChosenPoint = xTriangle[m];
                double yChosenPoint = yTriangle[m];
                double[][] chosenPointMatrix = {{xChosenPoint, yChosenPoint, 1}};
                for (int i = 0; i < 1; i++) {
                    for (int j = 0; j < 3; j++) {
                        double newValue = 0;
                        for (int k = 0; k < 3; k++) {
                            newValue = newValue + chosenPointMatrix[i][k] * scalingMatrix[k][j];
                        }
                        newCoords[i][j] = newValue;
                    }
                }
                xscale[m] = newCoords[0][0];
                yscale[m] = newCoords[0][1];

            }
            ObservableList<Double> newVal = FXCollections.observableArrayList();

            newVal.add(0, xscale[0]);
            newVal.add(1, yscale[0]);
            newVal.add(2, xscale[1]);
            newVal.add(3, yscale[1]);
            newVal.add(4, xscale[2]);
            newVal.add(5, yscale[2]);


            triangle.getPoints().setAll(newVal);
            System.out.println(xscale[0] + " " + yscale[0] + " " + xscale[1] + " " + yscale[1] + " " + xscale[2] + " " + yscale[2]);


            pane.getChildren().add(triangle);
        }
    }

    @FXML
    void SectionHandler(ActionEvent event)
    {

        line.setVisible(true);
        triangle.setVisible(false);
    }

    @FXML
    void TriangleHandler(ActionEvent event)
    {
        line.setVisible(false);
        triangle.setVisible(true);

    }

    @FXML
    void ToRightHandler(ActionEvent event)
    {
        int setX = Integer.parseInt(setXField.getText());
        int setY = Integer.parseInt(setYField.getText());

        System.out.println(setX + " " + setY);
        Line point = new Line();
        point.setStartX(setX);
        point.setStartY(setY);
        point.setEndX(setX);
        point.setEndY(setY);
        pane.getChildren().add(point);

        double sin = Math.sin(10*Math.PI/180);
        double cos = Math.cos(10*Math.PI/180);

        if (line.isVisible() == true)
        {

            double layoutX = line.getLayoutX();
            double layoutY = line.getLayoutY();

            System.out.println(layoutX);
            System.out.println(layoutY);
            System.out.println(setX);

            line.setLayoutX(setX);
            line.setLayoutY(setY);

            double layoutX1= line.getLayoutX();
            double layoutY1 = line.getLayoutY();

            System.out.println(layoutX1+ "f");
            System.out.println(layoutY1+ "f");

            double xStart = line.getStartX(),
                    xEnd = line.getEndX(),
                    yStart = line.getStartY(),
                    yEnd = line.getEndY();

            xSection[0] = xStart;
            xSection[1] = xEnd;

            ySection[0] = yStart;
            ySection[1] = yEnd;


            double xscale[] = new double[2];
            double yscale[] = new double[2];


            double[][] scalingMatrix = {
                    {cos, sin, 0},
                    {-sin, cos, 0},
                    {0, 0, 1}};

            double newCoords[][] = {{0, 0, 0}};

            for (int m = 0; m < 2; m++)
            {
                double xChosenPoint = xSection[m];
                double yChosenPoint = ySection[m];
                double[][] chosenPointMatrix = {{xChosenPoint, yChosenPoint, 1}};
                for (int i = 0; i < 1; i++)
                {
                    for (int j = 0; j < 3; j++)
                    {
                        double newValue = 0;
                        for (int k = 0; k < 3; k++)
                        {
                            newValue = newValue + chosenPointMatrix[i][k] * scalingMatrix[k][j];
                        }
                        newCoords[i][j] = newValue;
                    }
                }
                xscale[m] = newCoords[0][0];
                yscale[m] = newCoords[0][1];

            }
            for (int i = 0; i <2; i++)
            {
                if (i == 1)
                {
                    line.setStartX(xscale[i]);
                    line.setStartY(yscale[i]);
                    line.setEndX(xscale[i - 1]);
                    line.setEndY(yscale[i - 1]);
                }
                else
                {
                    line.setStartX(xscale[i]);
                    line.setStartY(yscale[i]);
                    line.setEndX(xscale[i + 1]);
                    line.setEndY(yscale[i + 1]);
                }

                pane.getChildren().addAll();
            }
        }

        if (triangle.isVisible() == true)
        {

            triangle.setLayoutX(setX);
            triangle.setLayoutY(setY);

            ObservableList<Double> trianglePoints = triangle.getPoints();

            double firstPointX = trianglePoints.get(0),
                    firstPointY = trianglePoints.get(1),
                    secondPointX = trianglePoints.get(2),
                    secondPointY = trianglePoints.get(3),
                    thirdPointX = trianglePoints.get(4),
                    thirdPointY = trianglePoints.get(5);


            xTriangle[0] = firstPointX;
            xTriangle[1] = secondPointX;
            xTriangle[2] = thirdPointX;
            yTriangle[0] = firstPointY;
            yTriangle[1] = secondPointY;
            yTriangle[2] = thirdPointY;

            double xscale[] = new double[3];
            double yscale[] = new double[3];

            double[][] scalingMatrix = {
                    {cos, sin, 0},
                    {-sin, cos, 0},
                    {0, 0, 1}};

            double newCoords[][] = {{0, 0, 0}};

            for (int m = 0; m < 3; m++) {
                double xChosenPoint = xTriangle[m];
                double yChosenPoint = yTriangle[m];
                double[][] chosenPointMatrix = {{xChosenPoint, yChosenPoint, 1}};
                for (int i = 0; i < 1; i++) {
                    for (int j = 0; j < 3; j++) {
                        double newValue = 0;
                        for (int k = 0; k < 3; k++) {
                            newValue = newValue + chosenPointMatrix[i][k] * scalingMatrix[k][j];
                        }
                        newCoords[i][j] = newValue;
                    }
                }
                xscale[m] = newCoords[0][0];
                yscale[m] = newCoords[0][1];

            }
            ObservableList<Double> newVal = FXCollections.observableArrayList();

            newVal.add(0, xscale[0]);
            newVal.add(1, yscale[0]);
            newVal.add(2, xscale[1]);
            newVal.add(3, yscale[1]);
            newVal.add(4, xscale[2]);
            newVal.add(5, yscale[2]);



            triangle.getPoints().setAll(newVal);
        }
    }

    @FXML
    void toLeftHandler(ActionEvent event)
    {
        int setX = Integer.parseInt(setXField.getText());
        int setY = Integer.parseInt(setYField.getText());
        Line point = new Line();
        point.setStartX(setX);
        point.setStartY(setY);
        point.setEndX(setX);
        point.setEndY(setY);
        pane.getChildren().add(point);

        double sin = Math.sin(10*Math.PI/180);
        double cos = Math.cos(10*Math.PI/180);

        if (line.isVisible() == true)
        {

            double layoutX = line.getLayoutX();
            double layoutY = line.getLayoutY();

            System.out.println(layoutX);
            System.out.println(layoutY);
            line.setLayoutX(setX);
            line.setLayoutY(setY);
            double xStart = line.getStartX(),
                    xEnd = line.getEndX(),
                    yStart = line.getStartY(),
                    yEnd = line.getEndY();

            xSection[0] = xStart;
            xSection[1] = xEnd;

            ySection[0] = yStart;
            ySection[1] = yEnd;


            double xscale[] = new double[2];
            double yscale[] = new double[2];


            double[][] scalingMatrix = {
                    {cos, -sin, 0},
                    {sin, cos, 0},
                    {0, 0, 1}};

            double newCoords[][] = {{0, 0, 0}};

            for (int m = 0; m < 2; m++)
            {
                double xChosenPoint = xSection[m];
                double yChosenPoint = ySection[m];
                double[][] chosenPointMatrix = {{xChosenPoint, yChosenPoint, 1}};
                for (int i = 0; i < 1; i++)
                {
                    for (int j = 0; j < 3; j++)
                    {
                        double newValue = 0;
                        for (int k = 0; k < 3; k++)
                        {
                            newValue = newValue + chosenPointMatrix[i][k] * scalingMatrix[k][j];
                        }
                        newCoords[i][j] = newValue;
                    }
                }
                xscale[m] = newCoords[0][0];
                yscale[m] = newCoords[0][1];

            }
            for (int i = 0; i <2; i++)
            {
                if (i == 1)
                {
                    line.setStartX(xscale[i]);
                    line.setStartY(yscale[i]);
                    line.setEndX(xscale[i - 1]);
                    line.setEndY(yscale[i - 1]);
                }
                else
                {
                    line.setStartX(xscale[i]);
                    line.setStartY(yscale[i]);
                    line.setEndX(xscale[i + 1]);
                    line.setEndY(yscale[i + 1]);
                }

//                line.setLayoutX(layoutX);
//                line.setLayoutY(layoutY);
                pane.getChildren().addAll();
            }
        }

        if (triangle.isVisible() == true)
        {

            double layoutX = triangle.getLayoutX(),
                    layoutY = triangle.getLayoutY();
            triangle.setLayoutX(setX);
            triangle.setLayoutY(setY);

            ObservableList<Double> trianglePoints = triangle.getPoints();

            double firstPointX = trianglePoints.get(0),
                    firstPointY = trianglePoints.get(1),
                    secondPointX = trianglePoints.get(2),
                    secondPointY = trianglePoints.get(3),
                    thirdPointX = trianglePoints.get(4),
                    thirdPointY = trianglePoints.get(5);


            xTriangle[0] = firstPointX;
            xTriangle[1] = secondPointX;
            xTriangle[2] = thirdPointX;
            yTriangle[0] = firstPointY;
            yTriangle[1] = secondPointY;
            yTriangle[2] = thirdPointY;


            double xscale[] = new double[3];
            double yscale[] = new double[3];


            double[][] scalingMatrix = {
                    {cos, -sin, 0},
                    {sin, cos, 0},
                    {0, 0, 1}};

            double newCoords[][] = {{0, 0, 0}};

            for (int m = 0; m < 3; m++) {
                double xChosenPoint = xTriangle[m];
                double yChosenPoint = yTriangle[m];
                double[][] chosenPointMatrix = {{xChosenPoint, yChosenPoint, 1}};
                for (int i = 0; i < 1; i++) {
                    for (int j = 0; j < 3; j++) {
                        double newValue = 0;
                        for (int k = 0; k < 3; k++) {
                            newValue = newValue + chosenPointMatrix[i][k] * scalingMatrix[k][j];
                        }
                        newCoords[i][j] = newValue;
                    }
                }
                xscale[m] = newCoords[0][0];
                yscale[m] = newCoords[0][1];

            }
            ObservableList<Double> newVal = FXCollections.observableArrayList();

            newVal.add(0, xscale[0]);
            newVal.add(1, yscale[0]);
            newVal.add(2, xscale[1]);
            newVal.add(3, yscale[1]);
            newVal.add(4, xscale[2]);
            newVal.add(5, yscale[2]);


            triangle.getPoints().setAll(newVal);
        }
    }

    double xSection[] = new double[2];
    double xTriangle[] = new double[3];

    double ySection[] = new double[2];
    double yTriangle[] = new double[3];


}
