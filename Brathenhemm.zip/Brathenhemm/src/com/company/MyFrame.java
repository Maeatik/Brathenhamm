package com.company;

import javax.swing.*;
import java.awt.*;

public class MyFrame extends JFrame
{
    GraphicsDemo graphicsDemo = new GraphicsDemo();


    public MyFrame()
    {

        this.setSize(800,600);
        this.setBackground(Color.WHITE);
        //this.setResizable(false);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        this.setTitle("Общий алгоритм Брезенхема");
        this.add(graphicsDemo);
        this.pack();
        this.setVisible(true);
    }


}
