package com.company;


import javax.swing.*;
import java.awt.*;
import java.awt.image.ImageObserver;
import java.text.AttributedCharacterIterator;

public class Main
{
    public static void main(String[] args)
    {
        MyFrame myFrame = new MyFrame();

    }
}


