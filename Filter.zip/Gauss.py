import os
import io
import random as rnd
import numpy as np
import matplotlib.pyplot as plt
from PIL import Image, ImageDraw
from numpy.fft import fft2, ifft2
from scipy.signal import gaussian


def wiener_filter(img, core, K):
    core /= np.sum(core)
    MU = np.copy(img)
    MU = fft2(MU)
    core = fft2(core, img.shape)
    core = np.conj(core) / (np.abs(core) ** 2 + K)
    MU = MU * core
    MU = np.abs(ifft2(MU))
    return MU

def gaussian_core(core_size=3):
     filter = gaussian(core_size, core_size / 3).reshape(core_size, 1)
     filter = np.dot(filter, filter.transpose())
     filter /= np.sum(filter)
     return filter

def rgb2gray(rgb):
    return np.dot(rgb[..., :3], [0.2989, 0.5870, 0.1140])

img = Image.open('file1.tiff')
draw = ImageDraw.Draw(img)
imgWiener = img
drawWiener = ImageDraw.Draw(imgWiener)
pix = img.load()

width = img.size[0]
height = img.size[1]

for x in range(width):
    for y in range(height):
        r = pix[x, y][0]
        g = pix[x, y][1]
        b = pix[x, y][2]
        randomGauss = rnd.gauss(0.3, 1) * 55
        r = r + randomGauss
        g = g + randomGauss
        b = b + randomGauss

        if b > 255:
            b = 255
        if b < 0:
            b = 0
        if r > 255:
            r = 255
        if r < 0:
            r = 0
        if g > 255:
            g = 255
        if g < 0:
            g = 0;
        r = round(r)
        g = round(g)
        b = round(b)
        draw.point((x,y), (r,g,b))

img.save("Gauss.tiff", "TIFF")

file_name = os.path.join('Gauss.tiff')
noisy_img = rgb2gray(plt.imread(file_name))

core = gaussian_core(20)
filtered_img = wiener_filter(noisy_img, core, K=10)

display = [filtered_img]
label = ['После фильтра Винера']

fig = plt.figure(figsize=(12, 10))

for i in range(len(display)):
    fig.add_subplot(2, 2, i + 1)
    plt.imshow(display[i], cmap='gray')
    plt.title(label[i])

png1 = io.BytesIO()
fig.savefig(png1, format = "png")
png2 = Image.open(png1)

png2.save("Wiener.tiff")
png1.close()